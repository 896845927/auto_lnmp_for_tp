
--
-- Dumping data for table `test_table`
--

INSERT INTO `test_table` (`val`) VALUES
(8),
(9);

